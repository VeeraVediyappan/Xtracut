# scanZone-UI

Use npm install, then npm start
