import _ from 'lodash'
import React from 'react'
import { Dropdown } from 'semantic-ui-react'

const timeslot = [
  {
    id: "01:00"
  },
  {
    id: "02:00"
  },
  {
    id: "03:00"
  },
  {
    id: "04:00"
  },
  {
    id: "05:00"
  },
  {
    id: "06:00"
  },
  {
    id: "07:00"
  },
  {
    id: "08:00"
  },
  {
    id: "09:00"
  },
  {
    id: "10:00"
  },
  {
    id: "11:00"
  },
  {
    id: "12:00"
  },
  {
    id: "13:00"
  },
  {
    id: "14:00"
  },
  {
    id: "15:00"
  },
  {
    id: "16:00"
  },
  {
    id: "17:00"
  },
  {
    id: "18:00"
  },
  {
    id: "19:00"
  },
  {
    id: "20:00"
  },
  {
    id: "21:00"
  },
  {
    id: "22:00"
  },
  {
    id: "23:00"
  },
  {
    id: "24:00"
  },
]

const stateOptions = timeslot.map((data, index) => ({
  key: index,
  text:data.id,
  value: data.id,
}))


const DropdownList = () => (<Dropdown style={{"margin-left": "3px"}} placeholder='Time Slot' search selection options={stateOptions} />)

export default DropdownList