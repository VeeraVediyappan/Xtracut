import React, { useState } from "react";
import { Icon, Label, Button,   List, Table} from "semantic-ui-react";
import PaymentModal from "./modal";

const StepThree = ({ reset, scanData }) => {
  console.log(scanData);
  const [modal, setModal] = useState(false);
  return (
    <div>
      <div>
        <PaymentModal modal={modal} setModal={setModal} scanData={scanData} />
        <List>
          <List.Item>
              <List.Content>
                Summary of Selection
              </List.Content>
            </List.Item>
            <List.Item>
              <List.Content>
                Scan Type: {scanData.primary}-{scanData.secondary}
              </List.Content>
            </List.Item>
            <List.Item>
              <List.Content>Locality: {scanData.locality}</List.Content>
            </List.Item>
            <List.Item>
              <List.Content>Center: {scanData.center}</List.Content>
            </List.Item>
          </List>
        <Button icon style={{ marginTop: 50 }} onClick={() => reset()}>
          Change Scan
        </Button>

        <Button
          icon
          labelPosition="right"
          color="orange"
          style={{ marginTop: 50 }}
          onClick={() => setModal(true)}
        >
          Book this Scan
          <Icon name="payment" />
        </Button>
      </div>
    </div>
  );
};

export default StepThree;