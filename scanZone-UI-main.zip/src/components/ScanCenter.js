import React, { useState } from "react";
import "../scancenter.css";
import { Icon, Label, Button, Rating, Transition } from "semantic-ui-react";

function ScanCenter(props) {
  const [imgSrc, setImgSrc] = useState("");
  const HoverImg = (e) => {
    setImgSrc(e.target.src);
  };
  let locality;
  let area;
  if(props.locality) {
    let splitData = props.locality.split(",");
    locality=splitData.length > 0 ? splitData[0] : props.locality;
    area=splitData.length > 1 ? splitData[1] : props.city;
  }
  return (
    <div>
      {/* filter search */}
      {/* <div className="filterBody">
        <div className="margAuto makeFlex">
          <div className="filterTextBox">
            <label className="filterLabel">Label1</label>
            <input className="filterInput" type="text" value="filterBody" />
          </div>
          <div className="filterTextBox">
            <label className="filterLabel">Label1</label>
            <input className="filterInput" type="text" value="filterBody" />
          </div>
          <div className="filterTextBox">
            <label className="filterLabel">Label1</label>
            <input className="filterInput" type="text" value="filterBody" />
          </div>
          <div className="filterTextBox">
            <label className="filterLabel">Label1</label>
            <input className="filterInput" type="text" value="filterBody" />
          </div>

          <input className= "buttonSearch" type="button" value="SEARCH"/>
        </div>
      </div> */}
      {/* card */}
      <div className="parentDiv">
        <div className="makeFlex">
        <a className="makeFlex flexOne" onClick={() => props.setCenter(locality)}>
           <div className="padding10">
              <img
                src={
                  imgSrc
                    ? imgSrc
                    : "http://r1imghtlak.mmtcdn.com/d94c1fa89cb211e9bbba0242ac110003.jpg?&output-quality=75&downsize=583:388&output-format=jpg"
                }
                height="162"
                width="243"
              />
              <div>
                <img
                  src="http://r1imghtlak.mmtcdn.com/d94c1fa89cb211e9bbba0242ac110003.jpg?&output-quality=75&downsize=583:388&output-format=jpg"
                  onMouseOver={HoverImg}
                  height="50"
                  width="56"
                />
                <img
                  src="//r2imghtlak.mmtcdn.com/r2-mmt-htl-image/htl-imgs/20090106161513779-e9c823e852be11e898fb0ae1a3af2532.jpg?&output-quality=75&downsize=583:388&output-format=jpg"
                  className="picGap"
                  onMouseOver={HoverImg}
                  height="50"
                  width="56"
                />
                <img
                  src="//r2imghtlak.mmtcdn.com/r2-mmt-htl-image/htl-imgs/20090106161513779-cf90a1d6536c11e88a2e0aa814dda0b8.jpg?&output-quality=75&downsize=583:388&output-format=jpg"
                  className="picGap"
                  onMouseOver={HoverImg}
                  height="50"
                  width="56"
                />
              </div>
            </div>
            <div className="padding10">
              <div className="titleClass makeFlex">
              {locality}
                <Rating icon='star' style={{ margin: 5 }} defaultRating={5} maxRating={5} />
              </div>
              <p itemprop="address" class="area font12 grayText latoBold appendBottom5">{area}</p>
              <p style={{"color": "lightgreen",
    margin: "20px 0 20px 0",
    display: "flex"}}><span>Reviewed by Indian Council of Medical Research</span></p>
              <ul class="amenList darkText">
              <li>
                <div class="iconAmenity appendRight5">
                <img src="//promos.makemytrip.com/images/highlighted/doctor_on_call.png" style={{width: 20}} alt=""/>
                </div>
                <span class="font12">Doctor on Call</span>
                </li>
                  <li>
                  <div class="iconAmenity appendRight5">
                  <img src="//promos.makemytrip.com/images/highlighted/childcare_services.png" style={{width: 20}} alt=""/>
                  </div>
                  <span class="font12">Childcare Services</span>
                  </li>
                  <li>
                    <div class="iconAmenity appendRight5">
                    <img src="//promos.makemytrip.com/images/highlighted/free_wi_fi.png" style={{width: 20}} alt=""/>
                    </div><span class="font12">Free Wi-Fi</span>
                  </li>
                </ul>
              
                {/* <span className="star-rating">
                  <input type="radio" id="5-stars" name="rating" value="5" />
                  <label className="star">
                    &#9733;
                  </label>
                  <input type="radio" id="4-stars" name="rating" value="4" />
                  <label className="star">
                    &#9733;
                  </label>
                  <input type="radio" id="3-stars" name="rating" value="3" />
                  <label  className="star">
                    &#9733;
                  </label>
                  <input type="radio" id="2-stars" name="rating" value="2" />
                  <label className="star">
                    &#9733;
                  </label>
                  <input type="radio" id="1-star" name="rating" value="1" />
                  <label className="star">
                    &#9733;
                  </label>
                </span> */}
                <p style={{display: "flex", "color": "lightgreen"}}><span >Safety, hygiene &amp; social distancing</span></p>

            </div>

          <div className="makeFlex columFlex borderLeft ">
         
          <div className="includeClass">
              included in this price
              <ul class="includes">
          <li class="greenText">
          <span class="includeIcon">
          <span class="sprite singleGreenTickIcon">
          </span>
          </span>
          <span class="includes__text">Free Cancellation</span>
          </li><li class="greenText"><span class="includeIcon">
          <span class="sprite singleGreenTickIcon"></span>
          </span>
          <span class="includes__text">GST price</span></li></ul>
            </div>
            <div className="priceContent ">
            <p class="latoBlack font26 blackText appendBottom5" id="hlistpg_hotel_shown_price">INR8,000</p>
              {/* <div className="saveINRTage">
                Save INR 1500 <span>Discount TAG</span>
              </div>
              <div className="totalPrice">INR 5999</div> */}
            </div>
          </div>
          </a>
        </div>
      </div>
    </div>
  );
}

export default ScanCenter;